package dev.anilbeesetti.nextplayer.core.domain

import dev.anilbeesetti.nextplayer.core.data.repository.fake.FakeMediaRepository
import dev.anilbeesetti.nextplayer.core.data.repository.fake.FakePreferencesRepository
import dev.anilbeesetti.nextplayer.core.model.Folder
import dev.anilbeesetti.nextplayer.core.model.Video
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class GetFolderTreeMediaUseCaseTest {

    private val mediaRepository = FakeMediaRepository()
    private val preferencesRepository = FakePreferencesRepository()

    private val getFolderTreeMediaUseCase = GetFolderTreeMediaUseCase(
        mediaRepository = mediaRepository,
        preferencesRepository = preferencesRepository,
        Dispatchers.Unconfined,
    )

    private val now = System.currentTimeMillis()
    private val oneDayMillis = 24 * 60 * 60 * 1000L
    private val folderPath = "/storage/emulated/0/Movies"

    private fun video(
        id: Long,
        addedDaysAgo: Long,
        watched: Boolean,
        parent: String = folderPath,
    ) = Video(
        id = id,
        path = "$parent/video_$id.mp4",
        parentPath = parent,
        duration = 1000,
        uriString = "content://media/external/video/media/$id",
        nameWithExtension = "video_$id.mp4",
        width = 1920,
        height = 1080,
        size = 1000,
        dateAdded = (now - addedDaysAgo * oneDayMillis) / 1000L,
        lastPlayedAt = if (watched) Date(now) else null,
    )

    @Test
    fun folderNewVideosCount_onlyCountsUnwatchedVideosAddedWithinLast7Days() = runTest {
        mediaRepository.videos.addAll(
            elements = listOf(
                video(
                    id = 1,
                    addedDaysAgo = 1,
                    watched = false,
                ), // new
                video(
                    id = 2,
                    addedDaysAgo = 6,
                    watched = false,
                ), // new
                video(
                    id = 3,
                    addedDaysAgo = 8,
                    watched = false,
                ), // too old, not new
                video(
                    id = 4,
                    addedDaysAgo = 1,
                    watched = true,
                ), // watched, not new
            ),
        )

        val media = getFolderTreeMediaUseCase(folderPath = null).first()

        val moviesFolder = media.folders.first { it.path == folderPath }
        assertEquals(
            4,
            moviesFolder.videosCount,
        )
        assertEquals(
            2,
            moviesFolder.newVideosCount,
        )
    }

    @Test
    fun folderNewVideosCount_isZeroWhenNoVideosAreNew() = runTest {
        mediaRepository.videos.addAll(
            elements = listOf(
                video(
                    id = 1,
                    addedDaysAgo = 10,
                    watched = false,
                ),
                video(
                    id = 2,
                    addedDaysAgo = 1,
                    watched = true,
                ),
            ),
        )

        val media = getFolderTreeMediaUseCase(folderPath = null).first()

        val moviesFolder = media.folders.first { it.path == folderPath }
        assertEquals(
            0,
            moviesFolder.newVideosCount,
        )
    }

    @Test
    fun folderNewVideosCount_includesNewVideosInNestedSubfolders() = runTest {
        val nestedFolder = "$folderPath/Action"
        mediaRepository.videos.addAll(
            elements = listOf(
                video(
                    id = 1,
                    addedDaysAgo = 1,
                    watched = false,
                ),
                video(
                    id = 2,
                    addedDaysAgo = 2,
                    watched = false,
                    parent = nestedFolder,
                ),
            ),
        )

        val media = getFolderTreeMediaUseCase(folderPath = null).first()

        val moviesFolder = media.folders.first { it.path == folderPath }
        assertEquals(
            1,
            moviesFolder.videosCount,
        )
        assertEquals(
            2,
            moviesFolder.newVideosCount,
        )
    }

    @Test
    fun folderNewVideosCount_respectsNewVideoThresholdPreference() = runTest {
        preferencesRepository.updateApplicationPreferences { it.copy(newVideoThresholdDays = 3) }
        mediaRepository.videos.addAll(
            elements = listOf(
                video(
                    id = 1,
                    addedDaysAgo = 2,
                    watched = false,
                ),
                video(
                    id = 2,
                    addedDaysAgo = 5,
                    watched = false,
                ),
            ),
        )

        val media = getFolderTreeMediaUseCase(folderPath = null).first()

        val moviesFolder = media.folders.first { it.path == folderPath }
        assertEquals(
            1,
            moviesFolder.newVideosCount,
        )
    }

    @Test
    fun folderNewVideosCount_excludesVideosFromExcludedFolders() = runTest {
        preferencesRepository.updateApplicationPreferences {
            it.copy(excludeFolders = listOf(element = folderPath))
        }
        mediaRepository.videos.addAll(
            elements = listOf(
                element = video(
                    id = 1,
                    addedDaysAgo = 1,
                    watched = false,
                ),
            ),
        )

        val media = getFolderTreeMediaUseCase(folderPath = null).first()

        assertEquals(
            emptyList<Folder>(),
            media.folders.filter { it.path == folderPath },
        )
    }
}
