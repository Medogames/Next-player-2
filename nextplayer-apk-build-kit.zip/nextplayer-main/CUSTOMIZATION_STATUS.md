# Next Player customization progress

This is an in-progress source modification based on the supplied Next Player project.

## Implemented in this pass

- Watch History entries are grouped under their watch date.
- Each Watch History row has an action to remove only that entry without clearing the rest of the history.
- Playback history now stores the media title in the local Room database, so the title can still be shown when the source video is no longer present.
- Folder sorting has separate optional preferences from video sorting, while preserving the old shared-sort behavior until a separate folder sort is chosen.

## Not implemented yet

- Pinned folders and manual drag-and-drop ordering for folders and videos.
- Persistent local thumbnail snapshots and thumbnail retention after deleting source videos.
- Folder cover selection (first/last/specific video or chosen image).
- Aggregate information for selecting multiple folders.
- Configurable pause between consecutive videos.
- Additional app color themes/palettes.
- The full MX Player-style subtitle customization surface (including color, outline, background opacity, alignment, and margin controls).

Google Drive integration is intentionally excluded.

## Build verification

`./gradlew assembleDebug` could not run in the build environment because the Gradle 9.9 distribution was not cached and network access to `services.gradle.org` was unavailable. The project therefore has not been compile-verified in this environment.
