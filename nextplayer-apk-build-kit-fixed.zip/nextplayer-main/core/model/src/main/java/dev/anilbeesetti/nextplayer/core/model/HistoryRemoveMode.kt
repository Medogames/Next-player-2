package dev.anilbeesetti.nextplayer.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class HistoryRemoveMode {
    SELECTION,
    BUTTON,
}
