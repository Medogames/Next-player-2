package dev.anilbeesetti.nextplayer.core.model

enum class Font {
    DEFAULT,
    MONOSPACE,
    SANS_SERIF,
    SERIF,
    CONDENSED,
    LIGHT,
    MEDIUM,
    CURSIVE,
    CASUAL,
}
