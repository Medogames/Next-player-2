package dev.anilbeesetti.nextplayer.core.model

import kotlinx.serialization.Serializable

@Serializable
data class ApplicationPreferences(
    val sortBy: Sort.By = Sort.By.TITLE,
    val sortOrder: Sort.Order = Sort.Order.ASCENDING,
    val folderSortBy: Sort.By? = null,
    val folderSortOrder: Sort.Order? = null,
    val themeConfig: ThemeConfig = ThemeConfig.SYSTEM,
    val useHighContrastDarkTheme: Boolean = false,
    val useDynamicColors: Boolean = true,
    val colorTheme: ColorTheme = ColorTheme.DEFAULT,
    val folderLayoutMode: MediaLayoutMode? = null,
    val customTheme: CustomThemeColors = CustomThemeColors(),
    val markLastPlayedMedia: Boolean = true,
    val isHistoryPaused: Boolean = false,
    val historyRemoveMode: HistoryRemoveMode = HistoryRemoveMode.SELECTION,
    val includeNetworkWatchHistory: Boolean = true,
    val excludeFolders: List<String> = emptyList(),
    val pinnedFolders: List<String> = emptyList(),
    val folderCovers: Map<String, String> = emptyMap(),
    val customVideoOrder: Map<String, List<String>> = emptyMap(),
    val mediaViewMode: MediaViewMode = MediaViewMode.FOLDERS,
    val mediaLayoutMode: MediaLayoutMode = MediaLayoutMode.LIST,

    // Network browser
    val networkSortBy: Sort.By = Sort.By.TITLE,
    val networkSortOrder: Sort.Order = Sort.Order.ASCENDING,
    val networkMediaLayoutMode: MediaLayoutMode = MediaLayoutMode.LIST,

    // Fields
    val showDurationField: Boolean = true,
    val showFolderDurationField: Boolean = true,
    val showExtensionField: Boolean = false,
    val showPathField: Boolean = true,
    val showResolutionField: Boolean = false,
    val showSizeField: Boolean = false,
    val showThumbnailField: Boolean = true,
    val showPlayedProgress: Boolean = true,

    val newVideoThresholdDays: Int = 7,

    // Thumbnail generation
    val thumbnailGenerationStrategy: ThumbnailGenerationStrategy =
        ThumbnailGenerationStrategy.FRAME_AT_PERCENTAGE,
    val thumbnailFramePosition: Float = DEFAULT_THUMBNAIL_FRAME_POSITION,
) {

    companion object {
        const val DEFAULT_THUMBNAIL_FRAME_POSITION = 0.33f
    }
}

/** Folders use their own layout when the user chose one; otherwise they follow the video layout. */
val ApplicationPreferences.effectiveFolderLayoutMode: MediaLayoutMode
    get() = folderLayoutMode ?: mediaLayoutMode
