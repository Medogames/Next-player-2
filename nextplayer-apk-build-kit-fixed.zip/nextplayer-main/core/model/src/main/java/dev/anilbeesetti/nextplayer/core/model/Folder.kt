package dev.anilbeesetti.nextplayer.core.model

import java.io.Serializable

const val FOLDER_COVER_FIRST = "first"
const val FOLDER_COVER_LAST = "last"
const val FOLDER_COVER_URI_PREFIX = "uri:"

data class Folder(
    val name: String,
    val path: String,
    val dateModified: Long,
    val parentPath: String? = null,
    val totalSize: Long = 0,
    val totalDuration: Long = 0,
    val videosCount: Int = 0,
    val foldersCount: Int = 0,
    val newVideosCount: Int = 0,
    val isPinned: Boolean = false,
    val coverUri: String? = null,
) : Serializable {
    companion object {
        val sample = Folder(
            name = "Folder 1",
            path = "/storage/emulated/0/DCIM/Camera/Live Photos",
            dateModified = 2000,
        )
    }
}

fun List<Folder>.findClosestFolder(videoPath: String): Folder? {
    val videoDirectory = videoPath.substringBeforeLast(delimiter = "/")

    return filter { folder ->
        // Match the folder itself or an ancestor, respecting path-segment boundaries so
        // that e.g. "/storage/Movies" is not treated as an ancestor of "/storage/Movies2".
        videoDirectory == folder.path || videoDirectory.startsWith(prefix = folder.path + "/")
    }.maxByOrNull { folder -> folder.path.length }
}
