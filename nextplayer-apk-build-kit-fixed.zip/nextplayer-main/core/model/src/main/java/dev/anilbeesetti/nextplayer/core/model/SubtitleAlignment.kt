package dev.anilbeesetti.nextplayer.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class SubtitleAlignment {
    CENTER,
    LEFT,
    RIGHT,
}
