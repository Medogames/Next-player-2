package dev.anilbeesetti.nextplayer.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class ColorTheme {
    DEFAULT,
    RED,
    BLUE,
    GREEN,
    PURPLE,
    ORANGE,
}
