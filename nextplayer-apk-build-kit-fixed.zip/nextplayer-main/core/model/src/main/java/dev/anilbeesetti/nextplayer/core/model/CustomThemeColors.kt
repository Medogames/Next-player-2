package dev.anilbeesetti.nextplayer.core.model

import kotlinx.serialization.Serializable

/**
 * User customizations on top of the selected color theme. Colors are stored as ARGB ints; `null`
 * means "keep the theme's own color".
 */
@Serializable
data class CustomThemeColors(
    val hueShift: Float = 0f,
    val saturation: Float = 1f,
    val brightness: Float = 0f,
    val vividInDark: Boolean = false,
    val primary: Int? = null,
    val background: Int? = null,
    val frame: Int? = null,
    val cards: Int? = null,
    val text: Int? = null,
    val secondaryText: Int? = null,
    val fileName: Int? = null,
    val progressBar: Int? = null,
)
