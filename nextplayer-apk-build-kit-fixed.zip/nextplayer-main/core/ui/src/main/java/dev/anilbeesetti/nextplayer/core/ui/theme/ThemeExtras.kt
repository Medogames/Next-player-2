package dev.anilbeesetti.nextplayer.core.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Extra user-chosen colors that are not part of the Material color scheme. */
data class ThemeExtraColors(
    val fileName: Color? = null,
    val progressBar: Color? = null,
)

val LocalThemeExtraColors = staticCompositionLocalOf { ThemeExtraColors() }

@Composable
fun fileNameColor(default: Color): Color = LocalThemeExtraColors.current.fileName ?: default

@Composable
fun progressBarColor(default: Color): Color = LocalThemeExtraColors.current.progressBar ?: default
