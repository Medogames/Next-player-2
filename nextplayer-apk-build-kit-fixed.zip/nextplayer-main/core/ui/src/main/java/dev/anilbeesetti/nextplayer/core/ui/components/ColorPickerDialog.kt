package dev.anilbeesetti.nextplayer.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R

private val presetColors = listOf(
    0xFFE00000, 0xFFFF6D00, 0xFFFFC107, 0xFF2E7D32, 0xFF00897B, 0xFF1565C0,
    0xFF6A3FC4, 0xFFD81B60, 0xFF212121, 0xFF616161, 0xFFEEEEEE, 0xFFFFFFFF,
).map { Color(it) }

@Composable
fun ColorPickerDialog(
    initial: Int?,
    fallback: Color,
    onPick: (Int?) -> Unit,
    onDismiss: () -> Unit,
) {
    val start = initial?.let { Color(it) } ?: fallback
    val startHsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(start.toArgb(), it) } }
    var hue by remember { mutableFloatStateOf(startHsv[0]) }
    var sat by remember { mutableFloatStateOf(startHsv[1]) }
    var value by remember { mutableFloatStateOf(startHsv[2]) }
    val current = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value)))

    NextDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = stringResource(R.string.theme_picker_title)) },
        content = {
            Column(modifier = Modifier.verticalScroll(state = rememberScrollState())) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(current),
                )
                Text(
                    text = "#%06X".format(0xFFFFFF and current.toArgb()),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Row(
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .horizontalScroll(state = rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    presetColors.forEach { preset ->
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(preset)
                                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable {
                                    val hsv = FloatArray(3)
                                    android.graphics.Color.colorToHSV(preset.toArgb(), hsv)
                                    hue = hsv[0]
                                    sat = hsv[1]
                                    value = hsv[2]
                                },
                        )
                    }
                }
                Text(text = stringResource(R.string.theme_hue), modifier = Modifier.padding(top = 8.dp))
                Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f)
                Text(text = stringResource(R.string.theme_saturation))
                Slider(value = sat, onValueChange = { sat = it }, valueRange = 0f..1f)
                Text(text = stringResource(R.string.theme_brightness))
                Slider(value = value, onValueChange = { value = it }, valueRange = 0f..1f)
            }
        },
        confirmButton = {
            TextButton(onClick = { onPick(current.toArgb()) }) {
                Text(text = stringResource(R.string.theme_picker_select))
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { onPick(null) }) {
                    Text(text = stringResource(R.string.theme_default))
                }
                TextButton(onClick = onDismiss) {
                    Text(text = stringResource(R.string.cancel))
                }
            }
        },
    )
}
