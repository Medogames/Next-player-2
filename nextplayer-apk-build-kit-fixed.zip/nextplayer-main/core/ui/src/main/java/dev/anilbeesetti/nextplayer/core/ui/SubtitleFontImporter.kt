package dev.anilbeesetti.nextplayer.core.ui

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** Copies a font file picked by the user into the app's storage so subtitles can use it. */
object SubtitleFontImporter {

    /** Returns the stored font's path, or null when the file is not a usable font. */
    fun import(context: Context, uri: Uri): String? = runCatching {
        val name = context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: "font.ttf"
        val extension = name.substringAfterLast('.', "").lowercase()
        val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            .let { if (extension in listOf("ttf", "otf", "ttc")) it else "$it.ttf" }
        val directory = File(context.filesDir, "subtitle_fonts").apply { mkdirs() }
        val target = File(directory, safeName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: return@runCatching null
        val typeface = Typeface.createFromFile(target)
        if (target.length() > 0L && typeface != Typeface.DEFAULT) {
            target.absolutePath
        } else {
            target.delete()
            null
        }
    }.getOrNull()
}
