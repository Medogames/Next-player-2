# Next Player customization progress

This is an in-progress source modification based on the supplied Next Player project.

## Implemented in this pass

- Watch History entries are grouped under their watch date.
- Each Watch History row has an action to remove only that entry without clearing the rest of the history.
- Playback history now stores the media title in the local Room database, so the title can still be shown when the source video is no longer present.
- Folder sorting has separate optional preferences from video sorting, while preserving the old shared-sort behavior until a separate folder sort is chosen.

## Not implemented yet

- Pinned folders and manual drag-and-drop ordering for folders and videos.
- Persistent local thumbnail snapshots and thumbnail retention after deleting source videos.
- Folder cover selection (first/last/specific video or chosen image).
- Aggregate information for selecting multiple folders.
- Configurable pause between consecutive videos.
- Additional app color themes/palettes.
- The full MX Player-style subtitle customization surface (including color, outline, background opacity, alignment, and margin controls).

Google Drive integration is intentionally excluded.

## Build verification

`./gradlew assembleDebug` could not run in the build environment because the Gradle 9.9 distribution was not cached and network access to `services.gradle.org` was unavailable. The project therefore has not been compile-verified in this environment.

## Batch 2 (watch history selection)

- Watch History: "Select videos" menu item, long-press to start multi-select, tap to toggle, Remove button with confirmation dialog.
- The X button on each row now asks for confirmation before removing.
- Not compile-verified locally; build on GitHub Actions first.

## Batch 3 (history thumbnails survive file deletion)

- New HistoryThumbnailStore: saves a small JPEG copy (filesDir/history_thumbs) of the thumbnail of every played video while its file still exists.
- ThumbnailView falls back to that copy when the original file can no longer be read.
- Not compile-verified locally; build on GitHub Actions first.

## Batch 4 (color themes)

- New ColorTheme preference (Default, Red/YouTube, Blue, Green, Purple, Orange) in Settings > Appearance > Color theme.
- Any non-default theme overrides dynamic colors; works with light/dark and the high-contrast dark option.
- Applied in MainActivity and PlayerActivity. Not compile-verified locally.

## Batch 5

- FIX: LocalMediaSynchronizer no longer deletes media_state rows that have a lastPlayedTime, so Watch History survives deleting the video file (original upstream behavior removed them).
- New setting Appearance > Watch history removal: Multi-select (long press, default) or X button per video. Both ask for confirmation.
- Quick settings dialog: clear sections View mode / Folders (layout + sort) / Videos (sort) / Fields, separated by dividers.
- Not compile-verified locally.
