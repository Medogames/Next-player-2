package dev.anilbeesetti.nextplayer.feature.more.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.base.DataState
import dev.anilbeesetti.nextplayer.core.ui.components.NextDialog
import dev.anilbeesetti.nextplayer.core.ui.components.NextTopAppBar
import dev.anilbeesetti.nextplayer.core.ui.components.WatchHistoryConfirmationDialog
import dev.anilbeesetti.nextplayer.core.ui.components.tvFocusRing
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import java.text.SimpleDateFormat
import java.util.Locale
import dev.anilbeesetti.nextplayer.core.ui.extensions.copy
import dev.anilbeesetti.nextplayer.feature.more.components.HistoryEmptyState
import dev.anilbeesetti.nextplayer.feature.videopicker.composables.CenterCircularProgressBar
import dev.anilbeesetti.nextplayer.feature.videopicker.composables.VideoListItem

@Composable
fun HistoryScreen(viewModel: HistoryViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    HistoryScreenContent(
        state = state,
        onAction = viewModel::onAction,
    )
}

@Composable
internal fun HistoryScreenContent(state: HistoryUiState, onAction: (HistoryAction) -> Unit) {
    var showClearConfirmation by rememberSaveable { mutableStateOf(value = false) }
    var enableHistoryConfirmation by rememberSaveable { mutableStateOf<Boolean?>(value = null) }
    var menuExpanded by remember { mutableStateOf(value = false) }

    Scaffold(
        topBar = {
            NextTopAppBar(
                title = stringResource(R.string.history),
                navigationIcon = {
                    FilledTonalIconButton(
                        onClick = { onAction(HistoryAction.NavigateUp) },
                        modifier = Modifier.tvFocusRing(),
                    ) {
                        Icon(
                            imageVector = NextIcons.ArrowBack,
                            contentDescription = stringResource(R.string.navigate_up),
                        )
                    }
                },
                actions = {
                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier.tvFocusRing(),
                        ) {
                            Icon(
                                imageVector = NextIcons.MoreVert,
                                contentDescription = stringResource(R.string.menu),
                            )
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = stringResource(
                                            id = if (state.preferences.isHistoryPaused) {
                                                R.string.turn_on_watch_history
                                            } else {
                                                R.string.turn_off_watch_history
                                            },
                                        ),
                                    )
                                },
                                onClick = {
                                    menuExpanded = false
                                    enableHistoryConfirmation = state.preferences.isHistoryPaused
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(text = stringResource(R.string.clear_history)) },
                                enabled = state.history.result.orEmpty().isNotEmpty(),
                                onClick = {
                                    menuExpanded = false
                                    showClearConfirmation = true
                                },
                            )
                        }
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
    ) { scaffoldPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(scaffoldPadding.copy(bottom = 0.dp))
                .clip(
                    shape = RoundedCornerShape(
                        topStart = 24.dp,
                        topEnd = 24.dp,
                    ),
                )
                .background(MaterialTheme.colorScheme.background),
        ) {
            if (state.preferences.isHistoryPaused) {
                HistoryEmptyState(
                    isHistoryOff = true,
                    modifier = Modifier.fillMaxSize().verticalScroll(state = rememberScrollState()),
                )
            } else {
                when (val history = state.history) {
                    is DataState.Loading -> CenterCircularProgressBar()

                    is DataState.Error -> Text(
                        text = history.value.message.orEmpty(),
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.error,
                    )

                    is DataState.Success -> if (history.value.isEmpty()) {
                        HistoryEmptyState(
                            isHistoryOff = false,
                            modifier = Modifier.fillMaxSize().verticalScroll(
                                state = rememberScrollState(),
                            ),
                        )
                    } else {
                        val dayFormatter = remember {
                            SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
                        }
                        val grouped = history.value.groupBy { video ->
                            video.lastPlayedAt?.let(dayFormatter::format) ?: "Unknown date"
                        }
                        LazyColumn(
                            contentPadding = PaddingValues(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            grouped.forEach { (day, videos) ->
                                item(key = "day-$day") {
                                    Text(
                                        text = day,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(
                                            horizontal = 12.dp,
                                            vertical = 10.dp,
                                        ),
                                    )
                                }
                                itemsIndexed(
                                    videos,
                                    key = { _, video -> video.uriString },
                                ) { index, video ->
                                    VideoListItem(
                                        video = video,
                                        isRecentlyPlayedVideo = false,
                                        preferences = state.preferences,
                                        isFirstItem = index == 0,
                                        isLastItem = index == videos.lastIndex,
                                        onClick = {
                                            onAction(HistoryAction.PlayVideo(video.uriString))
                                        },
                                        trailingContent = {
                                            IconButton(
                                                onClick = {
                                                    onAction(HistoryAction.RemoveVideo(video.uriString))
                                                },
                                            ) {
                                                Icon(
                                                    imageVector = NextIcons.Close,
                                                    contentDescription = "Remove from watch history",
                                                )
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    enableHistoryConfirmation?.let { enableHistory ->
        WatchHistoryConfirmationDialog(
            enableHistory = enableHistory,
            onConfirm = {
                onAction(HistoryAction.SetHistoryEnabled(enabled = enableHistory))
                enableHistoryConfirmation = null
            },
            onDismiss = { enableHistoryConfirmation = null },
        )
    }

    if (showClearConfirmation) {
        NextDialog(
            onDismissRequest = { showClearConfirmation = false },
            title = { Text(text = stringResource(R.string.clear_history)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onAction(HistoryAction.ClearHistory)
                        showClearConfirmation = false
                    },
                ) { Text(text = stringResource(R.string.clear_all)) }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmation = false }) {
                    Text(text = stringResource(R.string.cancel))
                }
            },
            content = { Text(text = stringResource(R.string.clear_history_confirmation)) },
        )
    }
}
