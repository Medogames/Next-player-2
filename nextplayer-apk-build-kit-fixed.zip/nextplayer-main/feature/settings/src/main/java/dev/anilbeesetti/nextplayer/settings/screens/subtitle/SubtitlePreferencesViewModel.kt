package dev.anilbeesetti.nextplayer.settings.screens.subtitle

import androidx.compose.runtime.Stable
import androidx.lifecycle.viewModelScope
import dev.anilbeesetti.nextplayer.core.data.repository.PreferencesRepository
import dev.anilbeesetti.nextplayer.core.model.Font
import dev.anilbeesetti.nextplayer.core.model.SubtitleAlignment
import dev.anilbeesetti.nextplayer.core.model.PlayerPreferences
import dev.anilbeesetti.nextplayer.core.ui.base.MviViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.InjectedParam
import org.koin.core.annotation.KoinViewModel

@KoinViewModel
class SubtitlePreferencesViewModel(
    private val preferencesRepository: PreferencesRepository,
    @InjectedParam internal var output: Output,
) : MviViewModel<SubtitlePreferencesUiState, SubtitlePreferencesUiEvent>() {

    data class Output(val navigateUp: () -> Unit)

    private val stateInternal = MutableStateFlow(
        value = SubtitlePreferencesUiState(
            preferences = preferencesRepository.playerPreferences.value,
        ),
    )
    override val state: StateFlow<SubtitlePreferencesUiState> = stateInternal.asStateFlow()

    init {
        viewModelScope.launch {
            preferencesRepository.playerPreferences.collect { preferences ->
                stateInternal.update { currentState ->
                    currentState.copy(preferences = preferences)
                }
            }
        }
    }

    override fun onAction(action: SubtitlePreferencesUiEvent) {
        when (action) {
            is SubtitlePreferencesUiEvent.NavigateUp -> output.navigateUp()

            is SubtitlePreferencesUiEvent.ShowDialog -> showDialog(action.value)

            is SubtitlePreferencesUiEvent.UpdateSubtitleLanguage -> updateSubtitleLanguage(
                action.value,
            )

            is SubtitlePreferencesUiEvent.UpdateSubtitleFont -> updateSubtitleFont(action.value)

            is SubtitlePreferencesUiEvent.ToggleSubtitleTextBold -> toggleSubtitleTextBold()

            is SubtitlePreferencesUiEvent.UpdateSubtitleFontSize -> updateSubtitleFontSize(
                action.value,
            )

            is SubtitlePreferencesUiEvent.ToggleSubtitleBackground -> toggleSubtitleBackground()

            is SubtitlePreferencesUiEvent.ToggleApplyEmbeddedStyles -> toggleApplyEmbeddedStyles()

            is SubtitlePreferencesUiEvent.UpdateSubtitleEncoding -> updateSubtitleEncoding(
                action.value,
            )

            is SubtitlePreferencesUiEvent.ToggleUseSystemCaptionStyle ->
                toggleUseSystemCaptionStyle()

            is SubtitlePreferencesUiEvent.ResetSubtitlePosition -> resetSubtitlePosition()

            is SubtitlePreferencesUiEvent.UpdateTextColor -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleTextColor = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateBackgroundColor -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleBackgroundColor = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateCustomFontPath -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleCustomFontPath = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateBackgroundOpacity -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleBackgroundOpacity = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateOutlineOpacity -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleOutlineOpacity = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateBackgroundPaddingX -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleBackgroundPaddingX = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateBackgroundPaddingY -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleBackgroundPaddingY = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateAlignment -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleAlignment = action.value)
                }
            }

            is SubtitlePreferencesUiEvent.UpdateOutlineColor -> viewModelScope.launch {
                preferencesRepository.updatePlayerPreferences {
                    it.copy(subtitleOutlineColor = action.value)
                }
            }
        }
    }

    private fun showDialog(value: SubtitlePreferenceDialog?) {
        stateInternal.update { it.copy(showDialog = value) }
    }

    private fun updateSubtitleLanguage(value: String) {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences {
                it.copy(preferredSubtitleLanguage = value)
            }
        }
    }

    private fun updateSubtitleFont(value: Font) {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences {
                it.copy(subtitleFont = value, subtitleCustomFontPath = null)
            }
        }
    }

    private fun toggleSubtitleTextBold() {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences {
                it.copy(subtitleTextBold = !it.subtitleTextBold)
            }
        }
    }

    private fun updateSubtitleFontSize(value: Int) {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences { it.copy(subtitleTextSize = value) }
        }
    }

    private fun toggleSubtitleBackground() {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences {
                it.copy(subtitleBackground = !it.subtitleBackground)
            }
        }
    }

    private fun toggleApplyEmbeddedStyles() {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences {
                it.copy(applyEmbeddedStyles = !it.applyEmbeddedStyles)
            }
        }
    }

    private fun updateSubtitleEncoding(value: String) {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences { it.copy(subtitleTextEncoding = value) }
        }
    }

    private fun resetSubtitlePosition() {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences { it.copy(subtitleOffsetY = 0f) }
        }
    }

    private fun toggleUseSystemCaptionStyle() {
        viewModelScope.launch {
            preferencesRepository.updatePlayerPreferences {
                it.copy(useSystemCaptionStyle = !it.useSystemCaptionStyle)
            }
        }
    }
}

@Stable
data class SubtitlePreferencesUiState(
    val showDialog: SubtitlePreferenceDialog? = null,
    val preferences: PlayerPreferences = PlayerPreferences(),
)

sealed interface SubtitlePreferenceDialog {
    data object SubtitleLanguageDialog : SubtitlePreferenceDialog
    data object SubtitleFontDialog : SubtitlePreferenceDialog
    data object SubtitleEncodingDialog : SubtitlePreferenceDialog
    data object TextColorDialog : SubtitlePreferenceDialog
    data object BackgroundColorDialog : SubtitlePreferenceDialog
    data object OutlineColorDialog : SubtitlePreferenceDialog
    data object AlignmentDialog : SubtitlePreferenceDialog
}

sealed interface SubtitlePreferencesUiEvent {
    data object NavigateUp : SubtitlePreferencesUiEvent

    data class ShowDialog(val value: SubtitlePreferenceDialog?) : SubtitlePreferencesUiEvent
    data class UpdateSubtitleLanguage(val value: String) : SubtitlePreferencesUiEvent
    data class UpdateSubtitleFont(val value: Font) : SubtitlePreferencesUiEvent
    data object ToggleSubtitleTextBold : SubtitlePreferencesUiEvent
    data class UpdateSubtitleFontSize(val value: Int) : SubtitlePreferencesUiEvent
    data object ToggleSubtitleBackground : SubtitlePreferencesUiEvent
    data object ToggleApplyEmbeddedStyles : SubtitlePreferencesUiEvent
    data class UpdateSubtitleEncoding(val value: String) : SubtitlePreferencesUiEvent
    data object ToggleUseSystemCaptionStyle : SubtitlePreferencesUiEvent
    data object ResetSubtitlePosition : SubtitlePreferencesUiEvent
    data class UpdateTextColor(val value: Int?) : SubtitlePreferencesUiEvent
    data class UpdateBackgroundColor(val value: Int?) : SubtitlePreferencesUiEvent
    data class UpdateOutlineColor(val value: Int?) : SubtitlePreferencesUiEvent
    data class UpdateCustomFontPath(val value: String?) : SubtitlePreferencesUiEvent
    data class UpdateBackgroundOpacity(val value: Int) : SubtitlePreferencesUiEvent
    data class UpdateOutlineOpacity(val value: Int) : SubtitlePreferencesUiEvent
    data class UpdateBackgroundPaddingX(val value: Int) : SubtitlePreferencesUiEvent
    data class UpdateBackgroundPaddingY(val value: Int) : SubtitlePreferencesUiEvent
    data class UpdateAlignment(val value: SubtitleAlignment) : SubtitlePreferencesUiEvent
}
