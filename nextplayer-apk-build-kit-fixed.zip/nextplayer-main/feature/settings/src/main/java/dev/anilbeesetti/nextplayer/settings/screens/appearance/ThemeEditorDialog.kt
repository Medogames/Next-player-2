package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import dev.anilbeesetti.nextplayer.core.model.ApplicationPreferences
import dev.anilbeesetti.nextplayer.core.model.ColorTheme
import dev.anilbeesetti.nextplayer.core.model.CustomThemeColors
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.ColorPickerDialog
import dev.anilbeesetti.nextplayer.core.ui.components.NextDialog
import dev.anilbeesetti.nextplayer.core.ui.theme.NextPlayerTheme
import dev.anilbeesetti.nextplayer.core.ui.theme.fileNameColor
import dev.anilbeesetti.nextplayer.core.ui.theme.progressBarColor
import kotlin.math.roundToInt

private enum class ColorRole(val labelRes: Int) {
    PRIMARY(R.string.theme_role_primary),
    BACKGROUND(R.string.theme_role_background),
    FRAME(R.string.theme_role_frame),
    CARDS(R.string.theme_role_cards),
    TEXT(R.string.theme_role_text),
    SECONDARY_TEXT(R.string.theme_role_secondary_text),
    FILE_NAME(R.string.theme_role_file_name),
    PROGRESS(R.string.theme_role_progress),
}

private fun ColorRole.get(colors: CustomThemeColors): Int? = when (this) {
    ColorRole.PRIMARY -> colors.primary
    ColorRole.BACKGROUND -> colors.background
    ColorRole.FRAME -> colors.frame
    ColorRole.CARDS -> colors.cards
    ColorRole.TEXT -> colors.text
    ColorRole.SECONDARY_TEXT -> colors.secondaryText
    ColorRole.FILE_NAME -> colors.fileName
    ColorRole.PROGRESS -> colors.progressBar
}

private fun ColorRole.set(colors: CustomThemeColors, value: Int?): CustomThemeColors =
    when (this) {
        ColorRole.PRIMARY -> colors.copy(primary = value)
        ColorRole.BACKGROUND -> colors.copy(background = value)
        ColorRole.FRAME -> colors.copy(frame = value)
        ColorRole.CARDS -> colors.copy(cards = value)
        ColorRole.TEXT -> colors.copy(text = value)
        ColorRole.SECONDARY_TEXT -> colors.copy(secondaryText = value)
        ColorRole.FILE_NAME -> colors.copy(fileName = value)
        ColorRole.PROGRESS -> colors.copy(progressBar = value)
    }

@Composable
fun ThemeEditorDialog(
    preferences: ApplicationPreferences,
    darkTheme: Boolean,
    onSave: (CustomThemeColors) -> Unit,
    onDismiss: () -> Unit,
) {
    var draft by remember { mutableStateOf(value = preferences.customTheme) }
    var pickingRole by remember { mutableStateOf<ColorRole?>(value = null) }
    var showSaveConfirm by remember { mutableStateOf(value = false) }
    var showResetConfirm by remember { mutableStateOf(value = false) }
    val toneEnabled = preferences.colorTheme != ColorTheme.DEFAULT

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier
                    .statusBarsPadding()
                    .navigationBarsPadding(),
            ) {
                Text(
                    text = stringResource(R.string.theme_editor_title),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(state = rememberScrollState())
                        .padding(horizontal = 20.dp),
                ) {
                    Text(
                        text = stringResource(R.string.theme_preview),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    NextPlayerTheme(
                        darkTheme = darkTheme,
                        highContrastDarkTheme = preferences.useHighContrastDarkTheme,
                        dynamicColor = preferences.useDynamicColors,
                        colorTheme = preferences.colorTheme,
                        customColors = draft,
                    ) {
                        ThemePreview()
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider()
                    Text(
                        text = stringResource(R.string.theme_tone_title),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 16.dp),
                    )
                    if (!toneEnabled) {
                        Text(
                            text = stringResource(R.string.theme_tone_needs_theme),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    ToneSlider(
                        label = stringResource(R.string.theme_hue),
                        valueText = "${draft.hueShift.roundToInt()}°",
                        value = draft.hueShift,
                        range = -180f..180f,
                        enabled = toneEnabled,
                        onChange = { draft = draft.copy(hueShift = it) },
                    )
                    ToneSlider(
                        label = stringResource(R.string.theme_saturation),
                        valueText = "${(draft.saturation * 100).roundToInt()}%",
                        value = draft.saturation,
                        range = 0f..2f,
                        enabled = toneEnabled,
                        onChange = { draft = draft.copy(saturation = it) },
                    )
                    ToneSlider(
                        label = stringResource(R.string.theme_brightness),
                        valueText = "${(draft.brightness * 100).roundToInt()}",
                        value = draft.brightness,
                        range = -0.5f..0.5f,
                        enabled = toneEnabled,
                        onChange = { draft = draft.copy(brightness = it) },
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = stringResource(R.string.theme_vivid_dark),
                            modifier = Modifier.weight(1f),
                        )
                        Switch(
                            checked = draft.vividInDark,
                            enabled = toneEnabled,
                            onCheckedChange = { draft = draft.copy(vividInDark = it) },
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        text = stringResource(R.string.theme_elements_title),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    ColorRole.entries.forEach { role ->
                        val value = role.get(draft)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { pickingRole = role }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(value?.let { Color(it) } ?: Color.Transparent)
                                    .border(
                                        width = 1.dp,
                                        color = MaterialTheme.colorScheme.outline,
                                        shape = CircleShape,
                                    ),
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = stringResource(role.labelRes))
                                Text(
                                    text = if (value == null) {
                                        stringResource(R.string.theme_default)
                                    } else {
                                        "#%06X".format(0xFFFFFF and value)
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
                HorizontalDivider()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(text = stringResource(R.string.cancel))
                    }
                    OutlinedButton(onClick = { showResetConfirm = true }) {
                        Text(text = stringResource(R.string.theme_reset))
                    }
                    Button(onClick = { showSaveConfirm = true }) {
                        Text(text = stringResource(R.string.theme_save))
                    }
                }
            }
        }
    }

    pickingRole?.let { role ->
        ColorPickerDialog(
            initial = role.get(draft),
            fallback = MaterialTheme.colorScheme.primary,
            onPick = { value ->
                draft = role.set(draft, value)
                pickingRole = null
            },
            onDismiss = { pickingRole = null },
        )
    }

    if (showSaveConfirm) {
        NextDialog(
            onDismissRequest = { showSaveConfirm = false },
            title = { Text(text = stringResource(R.string.theme_save_confirm_title)) },
            content = { Text(text = stringResource(R.string.theme_save_confirm_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSaveConfirm = false
                        onSave(draft)
                    },
                ) { Text(text = stringResource(R.string.theme_save_confirm_yes)) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveConfirm = false }) {
                    Text(text = stringResource(R.string.cancel))
                }
            },
        )
    }

    if (showResetConfirm) {
        NextDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text(text = stringResource(R.string.theme_reset)) },
            content = { Text(text = stringResource(R.string.theme_reset_confirm_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetConfirm = false
                        draft = CustomThemeColors()
                    },
                ) { Text(text = stringResource(R.string.theme_reset)) }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text(text = stringResource(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun ToneSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onChange: (Float) -> Unit,
) {
    Column(modifier = Modifier.padding(top = 8.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(text = label, modifier = Modifier.weight(1f))
            Text(text = valueText, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            enabled = enabled,
        )
    }
}

@Composable
private fun ThemePreview() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(12.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.background)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerLow)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    text = stringResource(R.string.theme_preview_video_name),
                    color = fileNameColor(MaterialTheme.colorScheme.onSurface),
                )
                Text(
                    text = "12:34 • 1080p",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                LinearProgressIndicator(
                    progress = { 0.6f },
                    modifier = Modifier.fillMaxWidth(),
                    color = progressBarColor(MaterialTheme.colorScheme.primary),
                    trackColor = MaterialTheme.colorScheme.secondaryContainer,
                )
            }
            Button(onClick = {}) {
                Text(text = stringResource(R.string.theme_preview_button))
            }
        }
    }
}
