package dev.anilbeesetti.nextplayer.settings.screens.subtitle

import android.content.Intent
import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import dev.anilbeesetti.nextplayer.core.model.SubtitleAlignment
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.PreviewLightDark
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.anilbeesetti.nextplayer.core.model.Font
import dev.anilbeesetti.nextplayer.core.model.PlayerPreferences
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.SubtitleFontImporter
import dev.anilbeesetti.nextplayer.core.ui.components.ColorPickerDialog
import dev.anilbeesetti.nextplayer.core.ui.components.ClickablePreferenceItem
import dev.anilbeesetti.nextplayer.core.ui.components.ListSectionTitle
import dev.anilbeesetti.nextplayer.core.ui.components.NextTopAppBar
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSlider
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSwitch
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSwitchWithDivider
import dev.anilbeesetti.nextplayer.core.ui.components.RadioTextButton
import dev.anilbeesetti.nextplayer.core.ui.components.rememberTvListFocusRequester
import dev.anilbeesetti.nextplayer.core.ui.components.tvFocusDown
import dev.anilbeesetti.nextplayer.core.ui.components.tvListFocus
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.theme.NextPlayerTheme
import dev.anilbeesetti.nextplayer.settings.composables.OptionsDialog
import dev.anilbeesetti.nextplayer.settings.extensions.name
import dev.anilbeesetti.nextplayer.settings.utils.LocalesHelper
import java.nio.charset.Charset

@Composable
fun SubtitlePreferencesScreen(viewModel: SubtitlePreferencesViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    SubtitlePreferencesScreenContent(
        state = state,
        onAction = viewModel::onAction,
    )
}

@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalMaterial3ExpressiveApi::class,
)
@Composable
private fun SubtitlePreferencesScreenContent(
    state: SubtitlePreferencesUiState,
    onAction: (SubtitlePreferencesUiEvent) -> Unit,
) {
    val languages = remember {
        listOf(
            element = Pair(
                first = "None",
                second = "",
            ),
        ) +
            LocalesHelper.getAvailableLocales()
    }
    val charsetResource = stringArrayResource(id = R.array.charsets_list)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fontPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                scope.launch {
                    val path = withContext(Dispatchers.IO) { SubtitleFontImporter.import(context, uri) }
                    if (path != null) {
                        onAction(SubtitlePreferencesUiEvent.UpdateCustomFontPath(path))
                    }
                }
            }
        },
    )

    val listFocusRequester = rememberTvListFocusRequester()
    Scaffold(
        topBar = {
            NextTopAppBar(
                title = stringResource(id = R.string.subtitle),
                navigationIcon = {
                    FilledTonalIconButton(
                        onClick = {
                            onAction(SubtitlePreferencesUiEvent.NavigateUp)
                        },
                        modifier = Modifier.tvFocusDown(target = listFocusRequester),
                    ) {
                        Icon(
                            imageVector = NextIcons.ArrowBack,
                            contentDescription = stringResource(id = R.string.navigate_up),
                        )
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(state = rememberScrollState())
                .tvListFocus(focusRequester = listFocusRequester)
                .padding(paddingValues = innerPadding)
                .padding(horizontal = 16.dp),
        ) {
            ListSectionTitle(text = stringResource(id = R.string.playback))
            Column(
                verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap),
            ) {
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.preferred_subtitle_lang),
                    description =
                        LocalesHelper.getLocaleDisplayLanguage(
                            state.preferences.preferredSubtitleLanguage,
                        )
                            .takeIf { it.isNotBlank() }
                            ?: stringResource(R.string.preferred_subtitle_lang_description),
                    icon = NextIcons.Language,
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.SubtitleLanguageDialog,
                            ),
                        )
                    },
                    isFirstItem = true,
                )
                ClickablePreferenceItem(
                    title = stringResource(R.string.subtitle_text_encoding),
                    description = charsetResource.first {
                        it.contains(state.preferences.subtitleTextEncoding)
                    },
                    icon = NextIcons.Subtitle,
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.SubtitleEncodingDialog,
                            ),
                        )
                    },
                    isLastItem = true,
                )
            }
            ListSectionTitle(text = stringResource(id = R.string.appearance_name))
            Column(
                verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap),
            ) {
                PreferenceSwitchWithDivider(
                    title = stringResource(R.string.system_caption_style),
                    description = stringResource(R.string.system_caption_style_desc),
                    icon = NextIcons.Caption,
                    isChecked = state.preferences.useSystemCaptionStyle,
                    onChecked = {
                        onAction(SubtitlePreferencesUiEvent.ToggleUseSystemCaptionStyle)
                    },
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_CAPTIONING_SETTINGS))
                    },
                    isFirstItem = true,
                    isLastItem = true,
                )
            }

            ListSectionTitle(text = stringResource(id = R.string.subtitle_section_text))
            Column(
                verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap),
            ) {
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.subtitle_font),
                    description = state.preferences.subtitleCustomFontPath
                        ?.let { File(it).nameWithoutExtension }
                        ?: state.preferences.subtitleFont.name(),
                    icon = NextIcons.Font,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.SubtitleFontDialog,
                            ),
                        )
                    },
                    isFirstItem = true,
                )
                PreferenceSwitch(
                    title = stringResource(id = R.string.subtitle_text_bold),
                    description = stringResource(id = R.string.subtitle_text_bold_desc),
                    icon = NextIcons.Bold,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    isChecked = state.preferences.subtitleTextBold,
                    onClick = { onAction(SubtitlePreferencesUiEvent.ToggleSubtitleTextBold) },
                )
                PreferenceSlider(
                    title = stringResource(id = R.string.subtitle_text_size),
                    description = state.preferences.subtitleTextSize.toString(),
                    icon = NextIcons.FontSize,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    value = state.preferences.subtitleTextSize.toFloat(),
                    valueRange = 10f..60f,
                    onValueChange = {
                        onAction(SubtitlePreferencesUiEvent.UpdateSubtitleFontSize(it.toInt()))
                    },
                    trailingContent = {
                        FilledIconButton(
                            enabled = state.preferences.useSystemCaptionStyle.not(),
                            onClick = {
                                onAction(
                                    SubtitlePreferencesUiEvent.UpdateSubtitleFontSize(
                                        PlayerPreferences.DEFAULT_SUBTITLE_TEXT_SIZE,
                                    ),
                                )
                            },
                        ) {
                            Icon(
                                imageVector = NextIcons.History,
                                contentDescription = stringResource(
                                    id = R.string.reset_seek_increment,
                                ),
                            )
                        }
                    },
                )
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.subtitle_text_color),
                    description = state.preferences.subtitleTextColor.colorLabel(),
                    icon = NextIcons.Font,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.TextColorDialog,
                            ),
                        )
                    },
                    isLastItem = true,
                )
            }

            ListSectionTitle(text = stringResource(id = R.string.subtitle_section_background))
            Column(
                verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap),
            ) {
                PreferenceSwitch(
                    title = stringResource(id = R.string.subtitle_background),
                    description = stringResource(id = R.string.subtitle_background_desc),
                    icon = NextIcons.Background,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    isChecked = state.preferences.subtitleBackground,
                    onClick = { onAction(SubtitlePreferencesUiEvent.ToggleSubtitleBackground) },
                    isFirstItem = true,
                )
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.subtitle_background_color),
                    description = state.preferences.subtitleBackgroundColor.colorLabel(),
                    icon = NextIcons.Background,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.BackgroundColorDialog,
                            ),
                        )
                    },
                )
                PreferenceSlider(
                    title = stringResource(id = R.string.subtitle_background_opacity),
                    description = "${state.preferences.subtitleBackgroundOpacity}%",
                    icon = NextIcons.Background,
                    enabled = state.preferences.useSystemCaptionStyle.not() &&
                        state.preferences.subtitleBackground,
                    value = state.preferences.subtitleBackgroundOpacity.toFloat(),
                    valueRange = 0f..100f,
                    onValueChange = {
                        onAction(SubtitlePreferencesUiEvent.UpdateBackgroundOpacity(it.toInt()))
                    },
                )
                PreferenceSlider(
                    title = stringResource(id = R.string.subtitle_padding_x),
                    description = "${state.preferences.subtitleBackgroundPaddingX} dp",
                    icon = NextIcons.Background,
                    enabled = state.preferences.useSystemCaptionStyle.not() &&
                        state.preferences.subtitleBackground,
                    value = state.preferences.subtitleBackgroundPaddingX.toFloat(),
                    valueRange = 0f..40f,
                    onValueChange = {
                        onAction(SubtitlePreferencesUiEvent.UpdateBackgroundPaddingX(it.toInt()))
                    },
                )
                PreferenceSlider(
                    title = stringResource(id = R.string.subtitle_padding_y),
                    description = "${state.preferences.subtitleBackgroundPaddingY} dp",
                    icon = NextIcons.Background,
                    enabled = state.preferences.useSystemCaptionStyle.not() &&
                        state.preferences.subtitleBackground,
                    value = state.preferences.subtitleBackgroundPaddingY.toFloat(),
                    valueRange = 0f..30f,
                    onValueChange = {
                        onAction(SubtitlePreferencesUiEvent.UpdateBackgroundPaddingY(it.toInt()))
                    },
                    isLastItem = true,
                )
            }

            ListSectionTitle(text = stringResource(id = R.string.subtitle_section_border))
            Column(
                verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap),
            ) {
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.subtitle_outline_color),
                    description = state.preferences.subtitleOutlineColor.colorLabel(),
                    icon = NextIcons.Style,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.OutlineColorDialog,
                            ),
                        )
                    },
                    isFirstItem = true,
                )
                PreferenceSlider(
                    title = stringResource(id = R.string.subtitle_outline_opacity),
                    description = "${state.preferences.subtitleOutlineOpacity}%",
                    icon = NextIcons.Style,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    value = state.preferences.subtitleOutlineOpacity.toFloat(),
                    valueRange = 0f..100f,
                    onValueChange = {
                        onAction(SubtitlePreferencesUiEvent.UpdateOutlineOpacity(it.toInt()))
                    },
                    isLastItem = true,
                )
            }

            ListSectionTitle(text = stringResource(id = R.string.subtitle_section_layout))
            Column(
                verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap),
            ) {
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.subtitle_alignment),
                    description = state.preferences.subtitleAlignment.label(),
                    icon = NextIcons.Subtitle,
                    enabled = state.preferences.useSystemCaptionStyle.not(),
                    onClick = {
                        onAction(
                            SubtitlePreferencesUiEvent.ShowDialog(
                                value = SubtitlePreferenceDialog.AlignmentDialog,
                            ),
                        )
                    },
                    isFirstItem = true,
                )
                PreferenceSwitch(
                    title = stringResource(R.string.embedded_styles),
                    description = stringResource(R.string.embedded_styles_desc),
                    icon = NextIcons.Style,
                    isChecked = state.preferences.applyEmbeddedStyles,
                    onClick = { onAction(SubtitlePreferencesUiEvent.ToggleApplyEmbeddedStyles) },
                )
                ClickablePreferenceItem(
                    title = stringResource(id = R.string.reset_subtitle_position),
                    description = stringResource(id = R.string.reset_subtitle_position_desc),
                    icon = NextIcons.History,
                    enabled = state.preferences.subtitleOffsetY != 0f,
                    onClick = { onAction(SubtitlePreferencesUiEvent.ResetSubtitlePosition) },
                    isLastItem = true,
                )
            }
        }

        state.showDialog?.let { showDialog ->
            when (showDialog) {
                SubtitlePreferenceDialog.SubtitleLanguageDialog -> {
                    OptionsDialog(
                        text = stringResource(id = R.string.preferred_subtitle_lang),
                        onDismissClick = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    ) {
                        items(items = languages) {
                            RadioTextButton(
                                text = it.first,
                                selected = it.second == state.preferences.preferredSubtitleLanguage,
                                onClick = {
                                    onAction(
                                        SubtitlePreferencesUiEvent.UpdateSubtitleLanguage(
                                            it.second,
                                        ),
                                    )
                                    onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                                },
                            )
                        }
                    }
                }

                SubtitlePreferenceDialog.TextColorDialog -> {
                    ColorPickerDialog(
                        initial = state.preferences.subtitleTextColor,
                        fallback = Color.White,
                        onPick = {
                            onAction(SubtitlePreferencesUiEvent.UpdateTextColor(it))
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                        onDismiss = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    )
                }

                SubtitlePreferenceDialog.BackgroundColorDialog -> {
                    ColorPickerDialog(
                        initial = state.preferences.subtitleBackgroundColor,
                        fallback = Color.Black,
                        onPick = {
                            onAction(SubtitlePreferencesUiEvent.UpdateBackgroundColor(it))
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                        onDismiss = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    )
                }

                SubtitlePreferenceDialog.OutlineColorDialog -> {
                    ColorPickerDialog(
                        initial = state.preferences.subtitleOutlineColor,
                        fallback = Color.Black,
                        onPick = {
                            onAction(SubtitlePreferencesUiEvent.UpdateOutlineColor(it))
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                        onDismiss = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    )
                }

                SubtitlePreferenceDialog.AlignmentDialog -> {
                    OptionsDialog(
                        text = stringResource(id = R.string.subtitle_alignment),
                        onDismissClick = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    ) {
                        items(SubtitleAlignment.entries.toTypedArray()) {
                            RadioTextButton(
                                text = it.label(),
                                selected = it == state.preferences.subtitleAlignment,
                                onClick = {
                                    onAction(SubtitlePreferencesUiEvent.UpdateAlignment(it))
                                    onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                                },
                            )
                        }
                    }
                }

                SubtitlePreferenceDialog.SubtitleFontDialog -> {
                    OptionsDialog(
                        text = stringResource(id = R.string.subtitle_font),
                        onDismissClick = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    ) {
                        item {
                            RadioTextButton(
                                text = stringResource(id = R.string.subtitle_font_custom),
                                selected = state.preferences.subtitleCustomFontPath != null,
                                onClick = {
                                    onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                                    fontPicker.launch(arrayOf("*/*"))
                                },
                            )
                        }
                        items(Font.entries.toTypedArray()) {
                            RadioTextButton(
                                text = it.name(),
                                selected = state.preferences.subtitleCustomFontPath == null &&
                                    it == state.preferences.subtitleFont,
                                onClick = {
                                    onAction(
                                        SubtitlePreferencesUiEvent.UpdateSubtitleFont(value = it),
                                    )
                                    onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                                },
                            )
                        }
                    }
                }

                SubtitlePreferenceDialog.SubtitleEncodingDialog -> {
                    OptionsDialog(
                        text = stringResource(id = R.string.subtitle_text_encoding),
                        onDismissClick = {
                            onAction(SubtitlePreferencesUiEvent.ShowDialog(value = null))
                        },
                    ) {
                        items(items = charsetResource) {
                            val currentCharset = it.substringAfterLast(
                                delimiter = "(",
                                missingDelimiterValue = "",
                            ).removeSuffix(suffix = ")")
                            if (currentCharset.isEmpty() || Charset.isSupported(currentCharset)) {
                                RadioTextButton(
                                    text = it,
                                    selected =
                                        currentCharset == state.preferences.subtitleTextEncoding,
                                    onClick = {
                                        onAction(
                                            SubtitlePreferencesUiEvent.UpdateSubtitleEncoding(
                                                value = currentCharset,
                                            ),
                                        )
                                        onAction(
                                            SubtitlePreferencesUiEvent.ShowDialog(value = null),
                                        )
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@PreviewLightDark
@Composable
private fun SubtitlePreferencesScreenPreview() {
    NextPlayerTheme {
        SubtitlePreferencesScreenContent(
            state = SubtitlePreferencesUiState(),
            onAction = {},
        )
    }
}

@Composable
private fun Int?.colorLabel(): String = if (this == null) {
    stringResource(id = R.string.theme_default)
} else {
    "#%06X".format(0xFFFFFF and this)
}

@Composable
private fun SubtitleAlignment.label(): String = stringResource(
    id = when (this) {
        SubtitleAlignment.CENTER -> R.string.subtitle_alignment_center
        SubtitleAlignment.LEFT -> R.string.subtitle_alignment_left
        SubtitleAlignment.RIGHT -> R.string.subtitle_alignment_right
    },
)
