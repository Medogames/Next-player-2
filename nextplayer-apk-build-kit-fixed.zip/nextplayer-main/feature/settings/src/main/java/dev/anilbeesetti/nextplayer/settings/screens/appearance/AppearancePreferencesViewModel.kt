package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.runtime.Stable
import androidx.lifecycle.viewModelScope
import dev.anilbeesetti.nextplayer.core.data.repository.PreferencesRepository
import dev.anilbeesetti.nextplayer.core.model.ApplicationPreferences
import dev.anilbeesetti.nextplayer.core.model.ColorTheme
import dev.anilbeesetti.nextplayer.core.model.CustomThemeColors
import dev.anilbeesetti.nextplayer.core.model.HistoryRemoveMode
import dev.anilbeesetti.nextplayer.core.model.ThemeConfig
import dev.anilbeesetti.nextplayer.core.ui.base.MviViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.InjectedParam
import org.koin.core.annotation.KoinViewModel

@KoinViewModel
class AppearancePreferencesViewModel(
    private val preferencesRepository: PreferencesRepository,
    @InjectedParam internal var output: Output,
) : MviViewModel<AppearancePreferencesUiState, AppearancePreferencesEvent>() {

    data class Output(val navigateUp: () -> Unit)

    private val stateInternal = MutableStateFlow(
        value = AppearancePreferencesUiState(
            preferences = preferencesRepository.applicationPreferences.value,
        ),
    )
    override val state: StateFlow<AppearancePreferencesUiState> = stateInternal.asStateFlow()

    init {
        viewModelScope.launch {
            preferencesRepository.applicationPreferences.collect { preferences ->
                stateInternal.update { it.copy(preferences = preferences) }
            }
        }
    }

    override fun onAction(action: AppearancePreferencesEvent) {
        when (action) {
            is AppearancePreferencesEvent.NavigateUp -> output.navigateUp()

            is AppearancePreferencesEvent.ShowDialog -> showDialog(action.value)

            is AppearancePreferencesEvent.ToggleDarkTheme -> toggleDarkTheme()

            is AppearancePreferencesEvent.UpdateThemeConfig -> updateThemeConfig(action.themeConfig)

            is AppearancePreferencesEvent.ToggleUseDynamicColors -> toggleUseDynamicColors()

            is AppearancePreferencesEvent.UpdateColorTheme -> updateColorTheme(action.colorTheme)

            is AppearancePreferencesEvent.UpdateCustomTheme -> updateCustomTheme(action.colors)

            is AppearancePreferencesEvent.UpdateHistoryRemoveMode ->
                updateHistoryRemoveMode(action.mode)

            is AppearancePreferencesEvent.ToggleUseHighContrastDarkTheme ->
                toggleUseHighContrastDarkTheme()
        }
    }

    private fun showDialog(value: AppearancePreferenceDialog?) {
        stateInternal.update { it.copy(showDialog = value) }
    }

    private fun toggleDarkTheme() {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(
                    themeConfig = if (it.themeConfig == ThemeConfig.ON) {
                        ThemeConfig.OFF
                    } else {
                        ThemeConfig.ON
                    },
                )
            }
        }
    }

    private fun updateThemeConfig(themeConfig: ThemeConfig) {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(themeConfig = themeConfig)
            }
        }
    }

    private fun updateColorTheme(colorTheme: ColorTheme) {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(colorTheme = colorTheme)
            }
        }
    }

    private fun updateHistoryRemoveMode(mode: HistoryRemoveMode) {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(historyRemoveMode = mode)
            }
        }
    }

    private fun updateCustomTheme(colors: CustomThemeColors) {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(customTheme = colors)
            }
        }
    }

    private fun toggleUseDynamicColors() {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(useDynamicColors = !it.useDynamicColors)
            }
        }
    }

    private fun toggleUseHighContrastDarkTheme() {
        viewModelScope.launch {
            preferencesRepository.updateApplicationPreferences {
                it.copy(useHighContrastDarkTheme = !it.useHighContrastDarkTheme)
            }
        }
    }
}

@Stable
data class AppearancePreferencesUiState(
    val showDialog: AppearancePreferenceDialog? = null,
    val preferences: ApplicationPreferences = ApplicationPreferences(),
)

sealed interface AppearancePreferencesEvent {
    data object NavigateUp : AppearancePreferencesEvent

    data class ShowDialog(val value: AppearancePreferenceDialog?) : AppearancePreferencesEvent
    data object ToggleDarkTheme : AppearancePreferencesEvent
    data class UpdateThemeConfig(val themeConfig: ThemeConfig) : AppearancePreferencesEvent
    data object ToggleUseDynamicColors : AppearancePreferencesEvent
    data class UpdateColorTheme(val colorTheme: ColorTheme) : AppearancePreferencesEvent
    data class UpdateCustomTheme(val colors: CustomThemeColors) : AppearancePreferencesEvent
    data class UpdateHistoryRemoveMode(val mode: HistoryRemoveMode) : AppearancePreferencesEvent
    data object ToggleUseHighContrastDarkTheme : AppearancePreferencesEvent
}

sealed interface AppearancePreferenceDialog {
    data object Theme : AppearancePreferenceDialog
    data object ColorThemePicker : AppearancePreferenceDialog
    data object HistoryRemoveModePicker : AppearancePreferenceDialog
}
