package dev.anilbeesetti.nextplayer.settings.extensions

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import dev.anilbeesetti.nextplayer.core.model.Font
import dev.anilbeesetti.nextplayer.core.ui.R

@Composable
fun Font.name(): String {
    val stringRes = when (this) {
        Font.DEFAULT -> R.string.default_name
        Font.MONOSPACE -> R.string.monospace
        Font.SANS_SERIF -> R.string.sans_serif
        Font.SERIF -> R.string.serif
        Font.CONDENSED -> R.string.font_condensed
        Font.LIGHT -> R.string.font_light
        Font.MEDIUM -> R.string.font_medium
        Font.CURSIVE -> R.string.font_cursive
        Font.CASUAL -> R.string.font_casual
    }

    return stringResource(id = stringRes)
}
