package dev.anilbeesetti.nextplayer.feature.videopicker.composables

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.core.net.toUri
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Keeps a small independent JPEG copy of the thumbnail of every video that was played, so the
 * Watch History can still show a picture after the original video file has been deleted.
 */
object HistoryThumbnailStore {

    private const val DIR_NAME = "history_thumbs"
    private const val MAX_WIDTH = 480

    fun snapshotFile(context: Context, uriString: String): File {
        val hash = MessageDigest.getInstance("SHA-1")
            .digest(uriString.toByteArray())
            .joinToString(separator = "") { "%02x".format(it) }
        return File(File(context.filesDir, DIR_NAME), "$hash.jpg")
    }

    /** Creates the snapshot once, only while the video file is still readable. */
    suspend fun ensureSnapshot(context: Context, uriString: String, durationMs: Long) {
        val target = snapshotFile(context, uriString)
        if (target.exists()) return
        withContext(Dispatchers.IO) {
            runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uriString.toUri())
                    val timeUs = if (durationMs > 0) durationMs * 1000L / 3 else 0L
                    val frame = retriever.getFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    ) ?: return@runCatching
                    val scaled = if (frame.width > MAX_WIDTH) {
                        val height = frame.height * MAX_WIDTH / frame.width
                        Bitmap.createScaledBitmap(frame, MAX_WIDTH, height, true)
                    } else {
                        frame
                    }
                    target.parentFile?.mkdirs()
                    val temp = File(target.parentFile, target.name + ".tmp")
                    temp.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    temp.renameTo(target)
                } finally {
                    runCatching { retriever.release() }
                }
            }
        }
    }
}
