package dev.anilbeesetti.nextplayer.feature.videopicker.composables

import android.content.Context
import coil3.SingletonImageLoader
import coil3.annotation.ExperimentalCoilApi
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Keeps an independent copy of the thumbnail the library shows for every video that was played,
 * so the Watch History can still show the same picture after the video file has been deleted.
 * The copy is taken from the image cache right after the normal thumbnail loaded successfully,
 * which guarantees it is exactly the picture the user already sees in the library.
 */
object HistoryThumbnailStore {

    private const val DIR_NAME = "history_thumbs_v2"
    private const val OLD_DIR_NAME = "history_thumbs"

    private val inFlight = ConcurrentHashMap.newKeySet<String>()

    fun snapshotFile(context: Context, uriString: String): File {
        val hash = MessageDigest.getInstance("SHA-1")
            .digest(uriString.toByteArray())
            .joinToString(separator = "") { "%02x".format(it) }
        return File(File(context.filesDir, DIR_NAME), "$hash.jpg")
    }

    @OptIn(ExperimentalCoilApi::class)
    suspend fun saveFromImageCache(context: Context, uriString: String) {
        val target = snapshotFile(context, uriString)
        if (target.exists() || !inFlight.add(uriString)) return
        try {
            withContext(Dispatchers.IO) {
                runCatching {
                    // Pictures saved by the earlier version used a different frame; drop them.
                    val oldDir = File(context.filesDir, OLD_DIR_NAME)
                    if (oldDir.exists()) oldDir.deleteRecursively()

                    val diskCache = SingletonImageLoader.get(context).diskCache
                    val snapshot = diskCache?.openSnapshot(uriString)
                    if (snapshot != null) {
                        snapshot.use {
                            val source = it.data.toFile()
                            if (source.length() > 0L) {
                                target.parentFile?.mkdirs()
                                val temp = File(
                                    target.parentFile,
                                    target.name + "." + System.nanoTime() + ".tmp",
                                )
                                source.copyTo(temp, overwrite = true)
                                if (!temp.renameTo(target)) temp.delete()
                            }
                        }
                    }
                }
            }
        } finally {
            inFlight.remove(uriString)
        }
    }
}
