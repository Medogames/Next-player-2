package dev.anilbeesetti.nextplayer.feature.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.model.Font
import dev.anilbeesetti.nextplayer.core.model.PlayerPreferences
import dev.anilbeesetti.nextplayer.core.model.SubtitleAlignment
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.SubtitleFontImporter
import dev.anilbeesetti.nextplayer.core.ui.components.ColorPickerDialog
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ColorTarget { TEXT, BACKGROUND, OUTLINE }

/** Subtitle style controls shown over the video, so changes can be seen while watching. */
@Composable
fun BoxScope.SubtitleCustomizationView(
    modifier: Modifier = Modifier,
    show: Boolean,
    preferences: PlayerPreferences,
    onUpdate: ((PlayerPreferences) -> PlayerPreferences) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var colorTarget by remember { mutableStateOf<ColorTarget?>(value = null) }
    var fontMenuOpen by remember { mutableStateOf(value = false) }
    val fontPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                scope.launch {
                    val path = withContext(Dispatchers.IO) {
                        SubtitleFontImporter.import(context, uri)
                    }
                    if (path != null) onUpdate { it.copy(subtitleCustomFontPath = path) }
                }
            }
        },
    )

    OverlayView(
        modifier = modifier,
        show = show,
        title = stringResource(R.string.subtitle_customization),
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(state = rememberScrollState())
                .padding(bottom = 24.dp)
                .padding(horizontal = 24.dp),
        ) {
            SectionLabel(text = stringResource(R.string.subtitle_section_text))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(text = stringResource(R.string.subtitle_font))
                Box {
                    FilledTonalButton(onClick = { fontMenuOpen = true }) {
                        Text(
                            text = preferences.subtitleCustomFontPath
                                ?.let { File(it).nameWithoutExtension }
                                ?: preferences.subtitleFont.label(),
                            maxLines = 1,
                        )
                    }
                    DropdownMenu(
                        expanded = fontMenuOpen,
                        onDismissRequest = { fontMenuOpen = false },
                    ) {
                        DropdownMenuItem(
                            text = { Text(text = stringResource(R.string.subtitle_font_custom)) },
                            onClick = {
                                fontMenuOpen = false
                                fontPicker.launch(arrayOf("*/*"))
                            },
                        )
                        Font.entries.forEach { font ->
                            DropdownMenuItem(
                                text = { Text(text = font.label()) },
                                onClick = {
                                    fontMenuOpen = false
                                    onUpdate {
                                        it.copy(subtitleFont = font, subtitleCustomFontPath = null)
                                    }
                                },
                            )
                        }
                    }
                }
            }
            SettingSlider(
                label = stringResource(R.string.subtitle_text_size),
                valueText = preferences.subtitleTextSize.toString(),
                value = preferences.subtitleTextSize.toFloat(),
                range = 10f..60f,
                onChange = { onUpdate { p -> p.copy(subtitleTextSize = it.toInt()) } },
            )
            SettingSwitch(
                label = stringResource(R.string.subtitle_text_bold),
                checked = preferences.subtitleTextBold,
                onChange = { onUpdate { p -> p.copy(subtitleTextBold = it) } },
            )
            ColorSetting(
                label = stringResource(R.string.subtitle_text_color),
                color = preferences.subtitleTextColor,
                fallback = Color.White,
                onClick = { colorTarget = ColorTarget.TEXT },
            )

            SectionLabel(text = stringResource(R.string.subtitle_section_background))
            SettingSwitch(
                label = stringResource(R.string.subtitle_background),
                checked = preferences.subtitleBackground,
                onChange = { onUpdate { p -> p.copy(subtitleBackground = it) } },
            )
            ColorSetting(
                label = stringResource(R.string.subtitle_background_color),
                color = preferences.subtitleBackgroundColor,
                fallback = Color.Black,
                onClick = { colorTarget = ColorTarget.BACKGROUND },
            )
            SettingSlider(
                label = stringResource(R.string.subtitle_background_opacity),
                valueText = "${preferences.subtitleBackgroundOpacity}%",
                value = preferences.subtitleBackgroundOpacity.toFloat(),
                range = 0f..100f,
                enabled = preferences.subtitleBackground,
                onChange = { onUpdate { p -> p.copy(subtitleBackgroundOpacity = it.toInt()) } },
            )
            SettingSlider(
                label = stringResource(R.string.subtitle_padding_x),
                valueText = "${preferences.subtitleBackgroundPaddingX} dp",
                value = preferences.subtitleBackgroundPaddingX.toFloat(),
                range = 0f..40f,
                enabled = preferences.subtitleBackground,
                onChange = { onUpdate { p -> p.copy(subtitleBackgroundPaddingX = it.toInt()) } },
            )
            SettingSlider(
                label = stringResource(R.string.subtitle_padding_y),
                valueText = "${preferences.subtitleBackgroundPaddingY} dp",
                value = preferences.subtitleBackgroundPaddingY.toFloat(),
                range = 0f..30f,
                enabled = preferences.subtitleBackground,
                onChange = { onUpdate { p -> p.copy(subtitleBackgroundPaddingY = it.toInt()) } },
            )

            SectionLabel(text = stringResource(R.string.subtitle_section_border))
            ColorSetting(
                label = stringResource(R.string.subtitle_outline_color),
                color = preferences.subtitleOutlineColor,
                fallback = Color.Black,
                onClick = { colorTarget = ColorTarget.OUTLINE },
            )
            SettingSlider(
                label = stringResource(R.string.subtitle_outline_opacity),
                valueText = "${preferences.subtitleOutlineOpacity}%",
                value = preferences.subtitleOutlineOpacity.toFloat(),
                range = 0f..100f,
                onChange = { onUpdate { p -> p.copy(subtitleOutlineOpacity = it.toInt()) } },
            )

            SectionLabel(text = stringResource(R.string.subtitle_section_layout))
            Text(text = stringResource(R.string.subtitle_alignment))
            Row(
                modifier = Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SubtitleAlignment.entries.forEach { alignment ->
                    FilterChip(
                        selected = preferences.subtitleAlignment == alignment,
                        onClick = { onUpdate { it.copy(subtitleAlignment = alignment) } },
                        label = { Text(text = alignment.label()) },
                    )
                }
            }

            Spacer(modifier = Modifier.size(16.dp))
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    onUpdate {
                        val defaults = PlayerPreferences()
                        it.copy(
                            subtitleTextSize = defaults.subtitleTextSize,
                            subtitleBackground = defaults.subtitleBackground,
                            subtitleFont = defaults.subtitleFont,
                            subtitleTextBold = defaults.subtitleTextBold,
                            subtitleTextColor = null,
                            subtitleBackgroundColor = null,
                            subtitleOutlineColor = null,
                            subtitleCustomFontPath = null,
                            subtitleBackgroundOpacity = defaults.subtitleBackgroundOpacity,
                            subtitleOutlineOpacity = defaults.subtitleOutlineOpacity,
                            subtitleBackgroundPaddingX = defaults.subtitleBackgroundPaddingX,
                            subtitleBackgroundPaddingY = defaults.subtitleBackgroundPaddingY,
                            subtitleAlignment = defaults.subtitleAlignment,
                            subtitleOffsetY = defaults.subtitleOffsetY,
                        )
                    }
                },
            ) { Text(text = stringResource(R.string.subtitle_reset_style)) }
        }
    }

    colorTarget?.let { target ->
        val initial = when (target) {
            ColorTarget.TEXT -> preferences.subtitleTextColor
            ColorTarget.BACKGROUND -> preferences.subtitleBackgroundColor
            ColorTarget.OUTLINE -> preferences.subtitleOutlineColor
        }
        ColorPickerDialog(
            initial = initial,
            fallback = if (target == ColorTarget.TEXT) Color.White else Color.Black,
            onPick = { value ->
                onUpdate {
                    when (target) {
                        ColorTarget.TEXT -> it.copy(subtitleTextColor = value)
                        ColorTarget.BACKGROUND -> it.copy(subtitleBackgroundColor = value)
                        ColorTarget.OUTLINE -> it.copy(subtitleOutlineColor = value)
                    }
                }
                colorTarget = null
            },
            onDismiss = { colorTarget = null },
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun SettingSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    enabled: Boolean = true,
) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = label)
            Text(text = valueText)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            enabled = enabled,
        )
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ColorSetting(label: String, color: Int?, fallback: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = label)
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(color?.let { Color(it) } ?: fallback)
                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
        )
    }
}

@Composable
private fun Font.label(): String = stringResource(
    id = when (this) {
        Font.DEFAULT -> R.string.default_name
        Font.MONOSPACE -> R.string.monospace
        Font.SANS_SERIF -> R.string.sans_serif
        Font.SERIF -> R.string.serif
        Font.CONDENSED -> R.string.font_condensed
        Font.LIGHT -> R.string.font_light
        Font.MEDIUM -> R.string.font_medium
        Font.CURSIVE -> R.string.font_cursive
        Font.CASUAL -> R.string.font_casual
    },
)

@Composable
private fun SubtitleAlignment.label(): String = stringResource(
    id = when (this) {
        SubtitleAlignment.CENTER -> R.string.subtitle_alignment_center
        SubtitleAlignment.LEFT -> R.string.subtitle_alignment_left
        SubtitleAlignment.RIGHT -> R.string.subtitle_alignment_right
    },
)
