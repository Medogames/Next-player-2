package dev.anilbeesetti.nextplayer.feature.player.extensions

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitHorizontalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import kotlin.math.abs
import kotlinx.coroutines.CancellationException

/**
 * Detects custom transform gestures including pan, zoom, and rotation gestures.
 * This function allows customization of gesture handling and locks gestures to pan and zoom if specified.
 * This is a custom implementation of the [androidx.compose.foundation.gestures.detectTransformGestures] function that allows for more granular control over the gestures.
 *
 * https://stackoverflow.com/questions/76370595/how-to-handle-horizontal-scroll-gesture-combined-with-transform-gestures-in-jetp/76374985#76374985
 *
 * @param panZoomLock If true, locks gestures to pan and zoom, ignoring rotation if the touch-slope threshold for rotation is not exceeded.
 * @param pass Specifies the type of pointer events to process (e.g., Main, Initial).
 * @param onGestureStart Function invoked when a gesture is initiated with the first down event. The function receives the initial pointer change.
 * @param onGesture Function invoked during each gesture update with details on the gesture including the centroid position, pan offset, zoom factor, rotation angle, the current primary
 *  pointer change, and the list of all pointer changes.
 * @param onGestureEnd Function invoked when the gesture ends. The function receives the final pointer change.
 */
suspend fun PointerInputScope.detectCustomTransformGestures(
    panZoomLock: Boolean = false,
    pass: PointerEventPass = PointerEventPass.Main,
    pointCount: Int = 2,
    onGestureStart: (PointerInputChange) -> Unit = {},
    onGesture: (
        centroid: Offset,
        pan: Offset,
        zoom: Float,
        rotation: Float,
    ) -> Unit,
    onGestureEnd: (PointerInputChange) -> Unit = {},
) {
    awaitEachGesture {
        var rotation = 0f
        var zoom = 1f
        var pan = Offset.Zero
        var pastTouchSlop = false
        val touchSlop = viewConfiguration.touchSlop
        var lockedToPanZoom = false
        var gestureStarted = false

        // Wait for at least one pointer to press down and set the first contact position
        val down: PointerInputChange = awaitFirstDown(
            requireUnconsumed = false,
            pass = pass,
        )

        var pointer = down
        // The main pointer is the one that is down initially
        var pointerId = down.id

        do {
            val event = awaitPointerEvent(pass = pass)

            // Count the number of pointers currently down
            val currentPointerCount = event.changes.count { it.pressed }

            // If any position change is consumed from another PointerInputChange
            // or pointer count requirement is not fulfilled
            val canceled = event.changes.any { it.isConsumed } || currentPointerCount != pointCount

            if (!canceled) {
                // Trigger onGestureStart only once when pointer count requirement is met
                if (!gestureStarted) {
                    gestureStarted = true
                    onGestureStart(pointer)
                }

                // Get a pointer that is down if the first pointer is up,
                // get another and use it if other pointers are also down
                // event.changes.first() doesn't return same order
                val pointerInputChange = event.changes.firstOrNull { it.id == pointerId }
                    ?: event.changes.first()

                // Next time will check the same pointer with this id
                pointerId = pointerInputChange.id
                pointer = pointerInputChange

                val zoomChange = event.calculateZoom()
                val rotationChange = event.calculateRotation()
                val panChange = event.calculatePan()

                if (!pastTouchSlop) {
                    zoom *= zoomChange
                    rotation += rotationChange
                    pan += panChange

                    val centroidSize = event.calculateCentroidSize(useCurrent = false)
                    val zoomMotion = abs(x = 1 - zoom) * centroidSize
                    val rotationMotion = abs(
                        x = rotation * kotlin.math.PI.toFloat() * centroidSize / 180f,
                    )
                    val panMotion = pan.getDistance()

                    if (zoomMotion > touchSlop ||
                        rotationMotion > touchSlop ||
                        panMotion > touchSlop
                    ) {
                        pastTouchSlop = true
                        lockedToPanZoom = panZoomLock && rotationMotion < touchSlop
                    }
                }

                if (pastTouchSlop) {
                    val centroid = event.calculateCentroid(useCurrent = false)
                    val effectiveRotation = if (lockedToPanZoom) 0f else rotationChange
                    if (effectiveRotation != 0f || zoomChange != 1f || panChange != Offset.Zero) {
                        onGesture(
                            centroid,
                            panChange,
                            zoomChange,
                            effectiveRotation,
                        )
                    }

                    event.changes.forEach {
                        if (it.positionChanged()) {
                            it.consume()
                        }
                    }
                }
            }
        } while (!canceled && event.changes.any { it.pressed })

        // Only trigger onGestureEnd if gesture was actually started
        if (gestureStarted) {
            onGestureEnd(pointer)
        }
    }
}

suspend fun PointerInputScope.detectCustomHorizontalDragGestures(
    shouldStartGesture: (Offset) -> Boolean = { true },
    onDragStart: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
    onDragCancel: () -> Unit = {},
    onHorizontalDrag: (change: PointerInputChange, dragAmount: Float) -> Unit,
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        // Reject the whole gesture before touch slop can move it out of a system edge.
        if (!shouldStartGesture(down.position)) return@awaitEachGesture
        var overSlop = 0f
        val drag = awaitHorizontalTouchSlopOrCancellation(down.id) { change, over ->
            change.consume()
            overSlop = over
        }
        if (drag != null && currentEvent.changes.count { it.pressed } == 1) {
            onDragStart.invoke(drag.position)
            try {
                onHorizontalDrag(
                    drag,
                    overSlop,
                )
                if (
                    horizontalDrag(drag.id) {
                        onHorizontalDrag(
                            it,
                            it.positionChange().x,
                        )
                        it.consume()
                    }
                ) {
                    onDragEnd()
                } else {
                    onDragCancel()
                }
            } catch (e: CancellationException) {
                // Restarting/removing pointerInput cancels the coroutine without a pointer up.
                onDragCancel()
                throw e
            }
        }
    }
}

/**
 * Press at a position accepted by [shouldStartGesture] and move: the drag starts as soon as the
 * finger passes the touch slop. From then on the pointer is consumed in the Initial pass so the
 * tap, seek, volume and zoom gestures back off. A press that lifts without moving is left alone.
 */
suspend fun PointerInputScope.detectSubtitleDragGestures(
    shouldStartGesture: (Offset) -> Boolean,
    onPressChange: (Boolean) -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
) {
    awaitEachGesture {
        val down = awaitFirstDown(
            requireUnconsumed = false,
            pass = PointerEventPass.Initial,
        )
        if (!shouldStartGesture(down.position)) return@awaitEachGesture

        // Pressed is reported straight away so the UI can show the subtitle can be moved.
        onPressChange(true)
        try {
            // Wait in the Initial pass: other detectors may already have consumed the down event.
            var movedPastSlop = false
            while (!movedPastSlop) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull { it.id == down.id }
                if (event.changes.count { it.pressed } > 1) return@awaitEachGesture
                if (change == null || !change.pressed) return@awaitEachGesture
                val delta = change.position - down.position
                if (abs(delta.x) > viewConfiguration.touchSlop && abs(delta.x) >= abs(delta.y)) {
                    return@awaitEachGesture
                }
                movedPastSlop = abs(delta.y) > viewConfiguration.touchSlop
                // Claim the move that crosses the slop, or the volume/seek swipes also start on it.
                if (movedPastSlop) change.consume()
            }

            onDragStart()
            var released = false
            try {
                onDrag(currentEvent.changes.first { it.id == down.id }.position - down.position)
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                    if (event.changes.count { it.pressed } > 1) break
                    if (change.isConsumed) break
                    if (change.pressed) onDrag(change.positionChange())
                    if (!change.pressed) {
                        released = true
                        change.consume()
                        break
                    }
                    change.consume()
                }
            } finally {
                if (released) onDragEnd() else onDragCancel()
            }
        } finally {
            onPressChange(false)
        }
    }
}

suspend fun PointerInputScope.detectCustomVerticalDragGestures(
    shouldStartGesture: (Offset) -> Boolean = { true },
    onDragStart: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
    onDragCancel: () -> Unit = {},
    onVerticalDrag: (change: PointerInputChange, dragAmount: Float) -> Unit,
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (!shouldStartGesture(down.position)) return@awaitEachGesture
        var overSlop = 0f
        val drag = awaitVerticalTouchSlopOrCancellation(down.id) { change, over ->
            change.consume()
            overSlop = over
        }
        if (drag != null && currentEvent.changes.count { it.pressed } == 1) {
            onDragStart.invoke(drag.position)
            onVerticalDrag.invoke(
                drag,
                overSlop,
            )
            if (verticalDrag(drag.id) {
                    onVerticalDrag(
                        it,
                        it.positionChange().y,
                    )
                    it.consume()
                }
            ) {
                onDragEnd()
            } else {
                onDragCancel()
            }
        }
    }
}
