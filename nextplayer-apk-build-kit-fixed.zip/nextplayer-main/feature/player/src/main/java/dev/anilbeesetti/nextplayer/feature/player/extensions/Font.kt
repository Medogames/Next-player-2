package dev.anilbeesetti.nextplayer.feature.player.extensions

import android.graphics.Typeface
import dev.anilbeesetti.nextplayer.core.model.Font

fun Font.toTypeface(): Typeface = when (this) {
    Font.DEFAULT -> Typeface.DEFAULT
    Font.MONOSPACE -> Typeface.MONOSPACE
    Font.SANS_SERIF -> Typeface.SANS_SERIF
    Font.SERIF -> Typeface.SERIF
    Font.CONDENSED -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
    Font.LIGHT -> Typeface.create("sans-serif-light", Typeface.NORMAL)
    Font.MEDIUM -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
    Font.CURSIVE -> Typeface.create("cursive", Typeface.NORMAL)
    Font.CASUAL -> Typeface.create("casual", Typeface.NORMAL)
}
