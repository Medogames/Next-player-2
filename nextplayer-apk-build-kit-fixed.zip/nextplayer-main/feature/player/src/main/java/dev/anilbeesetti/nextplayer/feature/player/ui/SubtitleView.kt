package dev.anilbeesetti.nextplayer.feature.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import android.text.BidiFormatter
import android.text.Layout
import android.util.TypedValue
import android.view.View
import android.view.accessibility.CaptioningManager
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.view.doOnPreDraw
import androidx.media3.common.text.Cue
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import dev.anilbeesetti.nextplayer.core.model.Font
import dev.anilbeesetti.nextplayer.core.model.SubtitleAlignment
import dev.anilbeesetti.nextplayer.feature.player.buttons.PlayerButtonBlackAlpha
import dev.anilbeesetti.nextplayer.feature.player.extensions.toTypeface
import dev.anilbeesetti.nextplayer.feature.player.state.CuesState
import dev.anilbeesetti.nextplayer.feature.player.state.SubtitlePositionState

@OptIn(
    UnstableApi::class,
    ExperimentalMaterial3ExpressiveApi::class,
)
@Composable
fun SubtitleView(
    modifier: Modifier = Modifier,
    bitmapModifier: Modifier = modifier,
    cuesState: CuesState,
    positionState: SubtitlePositionState,
    isInPictureInPictureMode: Boolean,
    configuration: SubtitleConfiguration,
) {
    val canReposition = cuesState.canReposition
    val currentCanReposition by rememberUpdatedState(canReposition)
    val highlighted = canReposition && positionState.isHighlighted
    // Playback keeps going while the subtitle is moved; the text on screen stays put until release.
    var frozenCues by remember { mutableStateOf<List<Cue>?>(null) }
    LaunchedEffect(highlighted) {
        frozenCues = cuesState.currentCues?.cues.takeIf { highlighted }
    }
    val displayedCues = frozenCues.takeIf { highlighted }
        ?: cuesState.currentCues?.cues
    var customBackgroundBounds by remember { mutableStateOf<Rect?>(null) }
    DisposableEffect(positionState) {
        onDispose { positionState.textBounds = null }
    }

    val buttonBackground = if (configuration.useMaterialYouControls) {
        IconButtonDefaults.filledTonalIconButtonColors().containerColor
    } else {
        PlayerButtonBlackAlpha
    }
    // The time row is drawn over the controls scrim, which disappears when dragging starts.
    val highlightBackground = if (configuration.controlsVisible) {
        buttonBackground
    } else {
        buttonBackground.compositeOver(PlayerButtonBlackAlpha)
    }

    AndroidView(
        modifier = (
            if (cuesState.currentCues?.cues?.any { it.bitmap != null } ==
                true
            ) {
                bitmapModifier
            } else {
                modifier
            }
            )
            .fillMaxSize()
            .graphicsLayer {
                translationY =
                    if (isInPictureInPictureMode ||
                        !canReposition
                    ) {
                        0f
                    } else {
                        positionState.translationYPx
                    }
            }
            .drawBehind {
                val bounds = customBackgroundBounds ?: return@drawBehind
                if (!configuration.usesCustomBackground || isInPictureInPictureMode) {
                    return@drawBehind
                }
                val padX = configuration.backgroundPaddingX.dp.toPx()
                val padY = configuration.backgroundPaddingY.dp.toPx()
                val baseColor = configuration.backgroundColor ?: android.graphics.Color.BLACK
                drawRoundRect(
                    color = Color(withOpacity(baseColor, configuration.backgroundOpacity)),
                    topLeft = Offset(bounds.left - padX, bounds.top - padY),
                    size = Size(bounds.width + padX * 2, bounds.height + padY * 2),
                    cornerRadius = CornerRadius(6.dp.toPx()),
                )
            }
            .drawBehind {
                if (!highlighted || isInPictureInPictureMode) return@drawBehind
                val bounds = positionState.textBounds?.inflate(4.dp.toPx()) ?: return@drawBehind
                drawRoundRect(
                    color = highlightBackground,
                    topLeft = bounds.topLeft,
                    size = bounds.size,
                    cornerRadius = CornerRadius(8.dp.toPx()),
                )
            },
        factory = { context ->
            SubtitleView(context).apply {
                setStyle(
                    createCaptionStyle(
                        context,
                        configuration,
                        highlighted = false,
                        customBackground = configuration.usesCustomBackground &&
                            !isInPictureInPictureMode,
                    ),
                )
                if (!configuration.useSystemCaptionStyle) {
                    setFixedTextSize(
                        TypedValue.COMPLEX_UNIT_SP,
                        configuration.textSize.toFloat(),
                    )
                }
                setApplyEmbeddedStyles(configuration.applyEmbeddedStyles)
                addOnLayoutChangeListener { view, _, _, _, _, _, _, _, _ ->
                    positionState.textBounds =
                        if (currentCanReposition) measureDrawnBounds(view) else null
                }
            }
        },
        update = { subtitleView ->
            subtitleView.setStyle(
                createCaptionStyle(
                    context = subtitleView.context,
                    configuration = configuration,
                    highlighted = highlighted,
                    customBackground = configuration.usesCustomBackground &&
                        !isInPictureInPictureMode,
                ),
            )
            subtitleView.setApplyEmbeddedStyles(configuration.applyEmbeddedStyles)
            subtitleView.setCues(alignedCues(displayedCues, configuration))
            if (isInPictureInPictureMode) {
                subtitleView.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION)
            } else {
                subtitleView.setFixedTextSize(
                    TypedValue.COMPLEX_UNIT_SP,
                    configuration.textSize.toFloat(),
                )
            }
            val needsCustomBackground = configuration.usesCustomBackground &&
                !isInPictureInPictureMode
            subtitleView.doOnPreDraw {
                val bounds = if (currentCanReposition || needsCustomBackground) {
                    measureDrawnBounds(it)
                } else {
                    null
                }
                positionState.textBounds = if (currentCanReposition) bounds else null
                customBackgroundBounds = if (needsCustomBackground) bounds else null
            }
        },
    )
}

// The subtitle view draws nothing but text, so whatever it paints is where the text is. Media3 does
// not expose the text bounds, so paint into a reduced bitmap and find the painted pixels.
private const val BOUNDS_SCALE = 3
private const val BOUNDS_MIN_ALPHA = 16

private fun measureDrawnBounds(view: View): Rect? {
    val width = view.width / BOUNDS_SCALE
    val height = view.height / BOUNDS_SCALE
    if (width == 0 || height == 0) return null

    val bitmap = Bitmap.createBitmap(
        width,
        height,
        Bitmap.Config.ARGB_8888,
    )
    val canvas = Canvas(bitmap)
    canvas.scale(
        1f / BOUNDS_SCALE,
        1f / BOUNDS_SCALE,
    )
    view.draw(canvas)
    val pixels = IntArray(width * height)
    bitmap.getPixels(
        pixels,
        0,
        width,
        0,
        0,
        width,
        height,
    )
    bitmap.recycle()

    var left = width
    var top = height
    var right = -1
    var bottom = -1
    for (y in 0 until height) {
        for (x in 0 until width) {
            if ((pixels[y * width + x] ushr 24) < BOUNDS_MIN_ALPHA) continue
            if (x < left) left = x
            if (x > right) right = x
            if (y < top) top = y
            if (y > bottom) bottom = y
        }
    }
    if (right < 0) return null
    return Rect(
        left = left.toFloat() * BOUNDS_SCALE,
        top = top.toFloat() * BOUNDS_SCALE,
        right = (right + 1).toFloat() * BOUNDS_SCALE,
        bottom = (bottom + 1).toFloat() * BOUNDS_SCALE,
    )
}

@OptIn(UnstableApi::class)
private fun createCaptionStyle(
    context: Context,
    configuration: SubtitleConfiguration,
    highlighted: Boolean,
    customBackground: Boolean = false,
): CaptionStyleCompat {
    val captioningManager = getSystemService(
        context,
        CaptioningManager::class.java,
    )
    val style = if (configuration.useSystemCaptionStyle && captioningManager != null) {
        CaptionStyleCompat.createFromCaptionStyle(captioningManager.userStyle)
    } else {
        CaptionStyleCompat(
            configuration.textColor ?: android.graphics.Color.WHITE,
            withOpacity(
                configuration.backgroundColor ?: android.graphics.Color.BLACK,
                configuration.backgroundOpacity,
            ).takeIf { configuration.showBackground && !customBackground }
                ?: android.graphics.Color.TRANSPARENT,
            android.graphics.Color.TRANSPARENT,
            if (configuration.outlineColor != null) {
                CaptionStyleCompat.EDGE_TYPE_OUTLINE
            } else {
                CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
            },
            withOpacity(
                configuration.outlineColor ?: android.graphics.Color.BLACK,
                configuration.outlineOpacity,
            ),
            Typeface.create(
                customTypeface(configuration.customFontPath) ?: configuration.font.toTypeface(),
                Typeface.BOLD.takeIf { configuration.textBold } ?: Typeface.NORMAL,
            ),
        )
    }
    if (!highlighted) return style
    return CaptionStyleCompat(
        style.foregroundColor,
        android.graphics.Color.TRANSPARENT,
        style.windowColor,
        style.edgeType,
        style.edgeColor,
        style.typeface,
    )
}

@Stable
data class SubtitleConfiguration(
    val useSystemCaptionStyle: Boolean,
    val showBackground: Boolean,
    val font: Font,
    val textSize: Int,
    val textBold: Boolean,
    val applyEmbeddedStyles: Boolean,
    val useMaterialYouControls: Boolean,
    val controlsVisible: Boolean,
    val textColor: Int? = null,
    val backgroundColor: Int? = null,
    val outlineColor: Int? = null,
    val customFontPath: String? = null,
    val backgroundOpacity: Int = 100,
    val outlineOpacity: Int = 100,
    val backgroundPaddingX: Int = 0,
    val backgroundPaddingY: Int = 0,
    val alignment: SubtitleAlignment = SubtitleAlignment.CENTER,
) {
    // When the user asks for extra room around the text, the background is drawn by the app
    // (so its width and height can be controlled) instead of by the subtitle renderer.
    val usesCustomBackground: Boolean
        get() = showBackground && !useSystemCaptionStyle &&
            (backgroundPaddingX > 0 || backgroundPaddingY > 0)
}

private val customTypefaces = HashMap<String, Typeface>()

/** Loads the font file the user imported; returns null when it is missing or invalid. */
private fun customTypeface(path: String?): Typeface? {
    if (path == null) return null
    customTypefaces[path]?.let { return it }
    val typeface = runCatching { Typeface.createFromFile(path) }.getOrNull() ?: return null
    customTypefaces[path] = typeface
    return typeface
}

private fun withOpacity(color: Int, percent: Int): Int {
    val alpha = (255 * percent.coerceIn(0, 100) / 100f).toInt()
    return (color and 0x00FFFFFF) or (alpha shl 24)
}

/** Moves text subtitles to the left or right when the user picked an alignment. */
@OptIn(UnstableApi::class)
private fun alignedCues(cues: List<Cue>?, configuration: SubtitleConfiguration): List<Cue>? {
    if (cues == null || configuration.useSystemCaptionStyle ||
        configuration.alignment == SubtitleAlignment.CENTER
    ) {
        return cues
    }
    val bidi = BidiFormatter.getInstance()
    return cues.map { cue ->
        val text = cue.text
        if (cue.bitmap != null || text == null) return@map cue
        val isRtl = bidi.isRtl(text)
        val left = configuration.alignment == SubtitleAlignment.LEFT
        // "Normal" alignment follows the text direction, so flip it for right-to-left text.
        val alignment = if (left != isRtl) {
            Layout.Alignment.ALIGN_NORMAL
        } else {
            Layout.Alignment.ALIGN_OPPOSITE
        }
        cue.buildUpon()
            .setTextAlignment(alignment)
            .setPosition(if (left) 0.04f else 0.96f)
            .setPositionAnchor(if (left) Cue.ANCHOR_TYPE_START else Cue.ANCHOR_TYPE_END)
            .build()
    }
}
